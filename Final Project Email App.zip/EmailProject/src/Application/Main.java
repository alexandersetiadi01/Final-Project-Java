package Application;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			
			// load file LoginInterface.fxml as the scene that will be shown up when the program starts
			Parent root = FXMLLoader.load(getClass().getResource("LoginInterface.fxml"));
			// set the size of the window
			Scene scene = new Scene(root, 517, 258);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Email App ver. 1.0");
			// set resizable to false so that user can not resize the screen
			primaryStage.setResizable(false);
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
