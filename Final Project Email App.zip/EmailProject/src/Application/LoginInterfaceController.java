package Application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javax.mail.AuthenticationFailedException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;

public class LoginInterfaceController implements Initializable {
	
	@FXML
	private Button signIn;
	@FXML
	private TextField usrname;
	@FXML
	private PasswordField password;
	
	public static Stage mainMenuStage;
	
	@FXML
	private void SignInButtonAction (ActionEvent ae) throws IOException, AuthenticationFailedException {
		
		if(ReceiveEmail.Inbox(usrname.getText(), password.getText())) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScene.fxml"));
			Parent mainApp = loader.load();
			MainSceneController MSC = (MainSceneController) loader.getController();
			Scene mainAppScene = new Scene(mainApp);
			
			// set the user email and password to what the user input in usrname textfield and password textfield 
			MSC.setUserInfo(usrname.getText(), password.getText());
		
			mainAppScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage appStage = (Stage) ((Node) ae.getSource()).getScene().getWindow();
			
			appStage.setResizable(false);
			appStage.setTitle("email app ver.1.0");
			appStage.setScene(mainAppScene);
			appStage.setResizable(false);	
			appStage.show();
			MSC.refreshInbox();
			LoginInterfaceController.mainMenuStage = appStage;
			
		}else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("WARNING!!!");
			alert.setHeaderText("Invalid Email Address Or Password !!!");
			alert.show();
		}
		
	}
	
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		//TODO
	}
}


