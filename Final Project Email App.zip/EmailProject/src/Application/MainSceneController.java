package Application;


import java.io.File;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.mail.Address;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Stage; 

public class MainSceneController implements Initializable{
	
	// fx:id    
	@FXML
	private Button Send;
	@FXML
	private Button Attach;
	@FXML
	private Button inbox;
	@FXML
	private Button loadText;
	@FXML
	public MenuBar Account;
	@FXML
	private MenuItem LogOut;
	@FXML
	private TextField To;
	@FXML
	private TextField Subject;
	@FXML
	private TextField AttachmentFile;
	@FXML
	private TextArea text;
	@FXML
	private TableColumn<Email, Integer> numberColumn;
	@FXML
	private TableColumn<Email, Date> dateColumn;
	@FXML
	private TableColumn<Email, String> senderColumn;
	@FXML
	private TableColumn<Email, String> subjectColumn;
	@FXML
	private TableView<Email> tableview;
	@FXML
	private WebView web;
	
	ObservableList<Email> oblist = FXCollections.observableArrayList();
	
	private static String getEmail;
	private static String getPass;
	public static String filePath = "";
	public static String fileName = "";
	//public static String htmlText;
	public static Stage loginStage;
	
	// all function for button reaction in the interface
	@FXML
	private void LogOutAction(ActionEvent ae) throws IOException {
		// logged out message
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(null);
		alert.setHeaderText("Logged Out");
		alert.setContentText("thank you for using our email app >_<");
		alert.showAndWait();
		
		// showing the window of the login screen
		Parent root = FXMLLoader.load(getClass().getResource("LoginInterface.fxml"));
		Scene scene = new Scene(root, 517, 258);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		
		Stage primaryStage = new Stage();
		primaryStage.setResizable(false);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Email App ver. 1.0");
		primaryStage.show();
		
		MainSceneController.loginStage = primaryStage;
		// close the login interface
		LoginInterfaceController.mainMenuStage.close();
		// set the user email and password to null when they logged out
		setUserInfo(null, null); 
		// clear everything in the inside the oblist
		oblist.clear();
	}
	
	@FXML
	private void AttachButtonAction(ActionEvent ae) {
		// multiple file chooser
		FileChooser chooseFile = new FileChooser();
		List<File> f = chooseFile.showOpenMultipleDialog(null);
		for (File file : f) 
		{
			AttachmentFile.setText(file.getAbsolutePath());
			fileName = file.getName();
			filePath = file.getAbsolutePath();
		}
	}
	
	@FXML
	private void sendButtonAction(ActionEvent ae)throws Exception{
		
		String to = To.getText();
		String subj = Subject.getText();
		String txt = text.getText();
		
		//if(to.isEmpty()) {
//		Alert alert = new Alert(AlertType.ERROR);
//		alert.setTitle("ERROR!!!");
//		alert.setHeaderText("No Email Address!!!");	
//		alert.setContentText("we need email address of the recipient to deliver this email");
//		//}
		//else if(!to.isEmpty()) {
		SendEmail.sendEmail(getEmail, getPass, to, subj, txt, filePath, fileName);
		
		// alert window to tell the user when the message is sent
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("message sent notification");
		alert.setHeaderText("Message successfully Sent >_<");
		alert.setContentText("we have delivered your message to " + to);
		alert.showAndWait();
		
		To.clear();
		Subject.clear();
		text.clear();
		AttachmentFile.clear();
		filePath = "";
		fileName = "";
		//}
	}
	
	@FXML 
	public void refreshInbox() throws IOException {
		
		//clearing the oblist
		oblist.clear(); 
		
		// loop to add class item which contain all the messages from the email to oblist
		for (int i = 0; i < ReceiveEmail.num.size(); i++) {
			oblist.add(new Email(ReceiveEmail.getNumber().get(i), ReceiveEmail.getDate().get(i), ReceiveEmail.getSender().get(i)
				, ReceiveEmail.getSubject().get(i), ReceiveEmail.getText().get(i)));
		}
	
		// set the value of each column in tableview
		numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
		dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
		senderColumn.setCellValueFactory(new PropertyValueFactory<>("sender"));
		subjectColumn.setCellValueFactory(new PropertyValueFactory<>("subject"));
		//textColumn.setCellValueFactory(new PropertyValueFactory<>("text"));
	
		// set oblist as the items that will be shown in the tableview
		tableview.setItems(oblist);
	}
	
	
	@FXML
	public void LoadMessageContent() throws IOException {
		// select a message by clicking on the tableview
		Email temp = tableview.getSelectionModel().getSelectedItem();
		String htmlText = temp.getText();
		
		// create an object for WebView
		WebView webPage = new WebView();
		// load the content that will be shown in the webview
		webPage.getEngine().loadContent(htmlText, "text/html");
		
		// create an object for vbox
		VBox vbox = new VBox(webPage);
		// create an object for scene 
		Scene scene = new Scene(vbox, 719, 526);
		
		// create an object for stage
		Stage webStage = new Stage();
		// set the scene 
		webStage.setScene(scene);
		// display it
		webStage.show();
		
	}
	
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO
	}
	
	public void setUserInfo(String email, String pass)
	{
		this.getEmail = email;
		this.getPass = pass;
	}
	
}
