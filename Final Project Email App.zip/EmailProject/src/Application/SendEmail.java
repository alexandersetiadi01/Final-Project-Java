package Application;

import javax.activation.DataHandler;

import javax.activation.DataSource;
import javax.activation.FileDataSource;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

//import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.Scanner;

public class SendEmail {
	
	public static void sendEmail(String myEmail, String password, String recepient, String subject, 
			String text, String filePath, String fileName) throws Exception
	{
		// set the port, host and authentication
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        // check the password and email address
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myEmail, password);
            }
        });
        
        // object to prepare a message to be sent
        Message message = prepareMessage(session, myEmail, recepient, subject, text, filePath, fileName);
        System.out.println("loading...");
    
        // send the message
        Transport.send(message);
        System.out.println("message sent successfully");
    }

    private static Message prepareMessage(Session session, String myEmail, String recepient, 
    		String subject, String text, String filePath, String fileName){
        try {
        	// object for Message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(myEmail));
            message.setRecipient(Message.RecipientType.CC, new InternetAddress(recepient));
            message.setSubject(subject);
            
            // checking if there is an attachment file or not
            // if there is an attachment, create 2 body for the message which contain the text and the attachment file that user input
            // if not, just set the text for the message to what the user input
            if(filePath != "" && fileName != "") {
            	 MimeBodyPart msgBodyPart1 = new MimeBodyPart();
                 msgBodyPart1.setText(text);
                 
                 MimeBodyPart msgBodyPart2 = new MimeBodyPart();
                 DataSource source = new FileDataSource(filePath);
                
             	 msgBodyPart2.setDataHandler(new DataHandler(source));
                 msgBodyPart2.setFileName(fileName);
             
                 Multipart multipart = new MimeMultipart();
                 multipart.addBodyPart(msgBodyPart1);
                 multipart.addBodyPart(msgBodyPart2);
                 message.setContent(multipart);
            }else {
                message.setText(text);
            }
            // return the message
            return message;
            
        }catch (Exception ex){
            ex.printStackTrace();
            Logger.getLogger(SendEmail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
