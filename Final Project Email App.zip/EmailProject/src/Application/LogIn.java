package Application;

import java.util.regex.Pattern;

public class LogIn {
	
	// checking email by the format of the address
	public static boolean emailValidator(String myEmail) {
		 String email_regex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
		 
		 Pattern pattern = Pattern.compile(email_regex);
		 if(myEmail == null) {
			 return false;
		 }else {
			 return pattern.matcher(myEmail).matches();
		 }
		 
	}
}
