package Application;
import java.io.BufferedReader;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import javax.mail.Folder;  
import javax.mail.Message;  
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;  
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeBodyPart;
import javax.security.auth.Subject;


public class ReceiveEmail {
	
	// Arraylist to store number of message in email inbox, date of when the email was sent,
	// the address of the sender, the subject of the email, and the text from the email 
	public static ArrayList<Integer> num = new ArrayList<Integer>();
	private static ArrayList<Date> date = new ArrayList<Date>();
	private static ArrayList<String> sender = new ArrayList<String>();
	private static ArrayList<String> subject = new ArrayList<String>();
	private static ArrayList<String> emailText = new ArrayList<String>();
	
	// getter function to return the array list 
	public static ArrayList<Integer> getNumber(){
		return num;
	}
	
	public static ArrayList<Date> getDate(){
		return date;
	}
	
	public static ArrayList<String> getSender(){
		return sender; 
	}
	
	public static ArrayList<String> getSubject(){
		return subject;
	}
	
	public static ArrayList<String> getText(){
		return emailText;
	}
	
	// inbox function to check and copy the message from the email itself
	public static boolean Inbox(String user, String pass) throws IOException 
	{
		try {
			// get the session object
			Properties prop = new Properties();
			prop.put("mail.pop3.host", "pop.gmail.com");
			prop.put("mail.pop3.port", "995");
			prop.put("mail.pop3.starttls.enable", "true");
			Session session = Session.getDefaultInstance(prop);
			
			//create pop3 store object and connect to pop 3
			Store emailStore = session.getStore("pop3s");
			emailStore.connect("pop.gmail.com",user, pass);
			//emailStore.connect(user, pass);
			
			// create the folder object and open the folder
			Folder Inbox = emailStore.getFolder("Inbox");
			Inbox.open(Folder.READ_ONLY);
		
			// retrieve the messages from the folder and store it in an array  
			Message[] messages = Inbox.getMessages();
			for(int i = 0; i < messages.length; i++) {
				Message message = messages[i];				
				String contentType = message.getContentType();
			    String messageContent="";
			   
			    if (contentType.contains("multipart")) {
			        Multipart multiPart = (Multipart) message.getContent();
			        int numberOfParts = multiPart.getCount();
			        for (int a = 0; a < numberOfParts; a++) {
			            MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart(a);
			            messageContent = part.getContent().toString();
			        }
			    }
			    else if (contentType.contains("text/plain") || contentType.contains("text/html")) {
			        Object content = message.getContent();
			        if (content != null) {
			            messageContent = content.toString();
			        }
			    }
			    
			    // adding all the email contents to the arraylist
				num.add(i + 1);
				sender.add(message.getFrom()[0].toString());
				subject.add(message.getSubject());
				emailText.add(messageContent);
				date.add(message.getSentDate());
			}
			
			//close the store and folder objects
			Inbox.close(false);
			emailStore.close();
			return true;
			
		}catch(NoSuchProviderException ex) {ex.printStackTrace();}
		catch(MessagingException ex) {ex.printStackTrace();}
		catch(IOException ex) {ex.printStackTrace();}
		return false;
	}
	
}
