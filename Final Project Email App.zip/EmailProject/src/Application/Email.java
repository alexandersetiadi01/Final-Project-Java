package Application;

import java.util.Date;

import javax.mail.Address;

public class Email {
	private int number;
	private Date date;
	private String sender;
	private String subject;
	private String text;
	// constructor
	public Email(int no, Date date, String sender, String subject, String text){
		this.number = no;
		this.date = date;
		this.sender = sender;
		this.subject = subject;
		this.text = text;
	}
	// getter function
	public int getNumber() {
		return number;
	}
	
	public Date getDate() {
		return date;
	}
	
	public String getSender() {
		return sender;
	}
	
	public String getSubject() {
		return subject;
	}
	
	public String getText() {
		return text;
	}
}
